#### Optimizing the t-test ####
# From Wickham's Advanced R, 17.9 (page 371)

m <- 1000
n <- 50
X <- matrix(rnorm(m*n, mean = 10, sd = 3), nrow = m)
grp <- rep(1:2, each = n/2)

# Using formula
system.time(for(i in 1:m) t.test(X[i, ] ~ grp)$stat)
# Using arguments
system.time(
  for(i in 1:m) t.test(X[i, grp ==1 ], X[i, grp == 2])$stat
)

# Use apply() to store calculations
compT <- function(x, grp){
  t.test(x[grp == 1], x[grp == 2])$stat
}
system.time(
  t1 <- apply(X, 1, compT, grp = grp)
)

# Optimize the t-test! The book walks you through, but it's good to 
# attempt each step on your own. 

# See source code: 
stats:::t.test.default
